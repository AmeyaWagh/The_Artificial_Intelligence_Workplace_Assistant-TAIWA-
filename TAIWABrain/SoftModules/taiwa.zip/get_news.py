from bs4 import BeautifulSoup
import requests
import if_speech
import time
import newsreader
import speechreco
speaknews = if_speech.if_speech("hindi")
speaknews.speak("Hello Sir, welcome to the news section")
speaknews.speak("Enter the number of the type of news you want to hear")
main = "http://timesofindia.indiatimes.com/rss.cms"

a = requests.get(main)

soup = BeautifulSoup(a.text,'html.parser')

soup1 = soup.find_all('table')
soup2 =  soup1[1].find_all('table')

soup3 = soup2[1].find_all('tr')
i = 1
link = []
data_list = []
for everyEle in soup3:
	news_type = everyEle.text.replace('More','')
	link.append(everyEle.a['href'])
	news_type1 = news_type.lower().split()
	data_list.append("".join(news_type1))
	print str(i) + ') ' + news_type
	i = i+1


reco = speechreco.speech_to_text(4000)
news = None
while news == None:
	news = reco.recognize_voice(data_list)
	if news == None:
		speaknews.speak("Sorry, I didn't get that. Try again")
		print "Sorry, I didn't get that. Try again"
#news = raw_input('Enter the number of the type of news: ')


#new_url = link[int(news)-1]
new_url = link[news]
#print new_url
#print type(str(new_url))
new_url = [new_url]
Reporter = newsreader.NewsFinder(new_url)
Reporter.surfPages()
Reporter.readnews()
