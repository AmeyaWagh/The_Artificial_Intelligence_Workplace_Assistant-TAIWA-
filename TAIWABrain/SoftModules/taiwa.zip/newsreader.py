from BeautifulSoup import *
import urllib2
import sys
import time
sys.path.append("/home/aditya/Cortana/predev/interfaces")

import if_speech

class NewsFinder:
	headlines={}
	def __init__(self,urls):
		self.urls=urls
		self.audio=if_speech.if_speech("hindi")

	def surfPages(self):
		for url in self.urls:
			page=urllib2.urlopen(url)
			source=BeautifulSoup(page.read())
#			print source
			self.__extractnews(source)
	
	def __extractnews(self,code):
		tags=code.findAll('item')
		for tag in tags:
			contents=tag.findChildren()
#			print contents
			self.headlines.update({contents[0].getText():contents[3].getText().split('&lt;')[0]})		

	def readnews(self):
		for headline,description in self.headlines.iteritems():
			print headline
#			print description
			self.audio.speak(headline)
#			self.audio.speak(description)
			time.sleep(1)


if __name__=='__main__':
	urls=['http://timesofindia.feedsportal.com/c/33039/f/533921/index.rss']
	Reporter=NewsFinder(urls)
	Reporter.surfPages()
	Reporter.readnews()
